
<?php 
require_once 'db2.php';
 
 
$bkname=$_POST["mysample1"]; 
$authname=$_POST['mysample2'];
$genname=$_POST['mysample3'];
 
   echo($bkname);
   echo($authname);
   echo($genname);
 ?>